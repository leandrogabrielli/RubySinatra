<?php

namespace AppBundle\Controller;

use AppBundle\Entity\Crud;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;

use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;


class CrudController extends Controller{
    /**
     * @Route("/", name="crud_list")
     */
    public function listAction(Request $request){
        $cruds = $this->getDoctrine()
            ->getRepository('AppBundle:Crud')
            ->findAll();
        return $this->render('crud/index.html.twig', array(
            'cruds' => $cruds
        ));
    }
    /**
     * @Route("/crud/create", name="crud_create")
     */
    public function createAction(Request $request){
        $crud = new Crud;

        $form = $this->createFormBuilder($crud)
            ->add('name', TextType::class, array('attr' => array('class' => 'form-control', 'style' => 'margin-bottom:15px')))
            ->add('mail', TextType::class, array('attr' => array('class' => 'form-control', 'style' => 'margin-bottom:15px')))
            ->add('message', TextareaType::class, array('attr' => array('class' => 'form-control', 'style' => 'margin-bottom:15px')))
            ->add('save', SubmitType::class, array('label' => 'Guardar Usuario', 'attr' => array('class' => 'btn btn-primary', 'style' => 'margin-bottom:15px')))
            ->getForm();

        $form->handleRequest($request);

        if($form->isSubmitted() && $form->isValid()) {
            // Traer los datos
            $name = $form['name']->getData();
            $mail = $form['mail']->getData();
            $message = $form['message']->getData();
        
            $crud->setName($name);
            $crud->setMail($mail);
            $crud->setMessage($message);

            $em = $this->getDoctrine()->getManager();

            $em->persist($crud);
            $em->flush();

            $this->addFlash(
                'notice',
                'Usuario Creado'
                );

            return $this->redirectToRoute('crud_list');
        }

        return $this->render('crud/create.html.twig', array(
            'form' => $form->createView()
            )); 
    }
    /**
     * @Route("/crud/edit/{id}", name="crud_edit")
     */
    public function editAction($id, Request $request){
        $crud = $this->getDoctrine()
            ->getRepository('AppBundle:Crud')
            ->find($id);

        $crud->setName($crud->getName());
        $crud->setMail($crud->getMail());
        $crud->setMessage($crud->getMessage());
    

        $form = $this->createFormBuilder($crud)
            ->add('name', TextType::class, array('attr' => array('class' => 'form-control', 'style' => 'margin-bottom:15px')))
            ->add('mail', TextType::class, array('attr' => array('class' => 'form-control', 'style' => 'margin-bottom:15px')))
            ->add('message', TextareaType::class, array('attr' => array('class' => 'form-control', 'style' => 'margin-bottom:15px')))
            ->add('save', SubmitType::class, array('label' => 'Actualizar Datos', 'attr' => array('class' => 'btn btn-primary', 'style' => 'margin-bottom:15px')))
            ->getForm();

        $form->handleRequest($request);

        if($form->isSubmitted() && $form->isValid()) {
            // Traer los datos
            $name = $form['name']->getData();
            $mail = $form['mail']->getData();
            $message = $form['message']->getData();

            $em = $this->getDoctrine()->getManager();
            $crud = $em->getRepository('AppBundle:Crud')->find($id);

            $crud->setName($name);
            $crud->setMail($mail);
            $crud->setMessage($message);
            


            $em->flush();

            $this->addFlash(
                'notice',
                'Datos Actualizados'
                );

            return $this->redirectToRoute('crud_list');
        }



        return $this->render('crud/edit.html.twig', array(
            'crud' => $crud,
            'form' => $form->createView()
        ));   
    }
    /**
     * @Route("/crud/details/{id}", name="crud_details")
     */
    public function detailsAction($id){
        $crud = $this->getDoctrine()
            ->getRepository('AppBundle:Crud')
            ->find($id);

        return $this->render('crud/details.html.twig', array(
            'crud' => $crud
        ));
    }

    /**
    * @Route("/crud/delete/{id}", name="crud_delete")
    */
    public function deleteAction($id){
        $em = $this->getDoctrine()->getManager();
        $crud = $em->getRepository('AppBundle:Crud')->find($id);
        
        $em->remove($crud);
        $em->flush();

        $this->addFlash(
            'notice',
            'Usuario Eliminado'
            );

            return $this->redirectToRoute('crud_list');



    }


}
