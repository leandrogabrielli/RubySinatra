<?php

/* @Twig/Exception/exception_full.html.twig */
class __TwigTemplate_fb76c117fd33e59112267de90e089437e2c8814b6d184f9896c58d4f531eb3f5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@Twig/layout.html.twig", "@Twig/Exception/exception_full.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@Twig/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_aa91162caae2571b758cb9150dc9dabd4caef062631705029cf66d71a580b91b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_aa91162caae2571b758cb9150dc9dabd4caef062631705029cf66d71a580b91b->enter($__internal_aa91162caae2571b758cb9150dc9dabd4caef062631705029cf66d71a580b91b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception_full.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_aa91162caae2571b758cb9150dc9dabd4caef062631705029cf66d71a580b91b->leave($__internal_aa91162caae2571b758cb9150dc9dabd4caef062631705029cf66d71a580b91b_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_f2aad5bcc79d21538a1867dae87a2604f230168397d88a0f6a9cee09b135a9fa = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f2aad5bcc79d21538a1867dae87a2604f230168397d88a0f6a9cee09b135a9fa->enter($__internal_f2aad5bcc79d21538a1867dae87a2604f230168397d88a0f6a9cee09b135a9fa_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    <link href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\HttpFoundationExtension')->generateAbsoluteUrl($this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/framework/css/exception.css")), "html", null, true);
        echo "\" rel=\"stylesheet\" type=\"text/css\" media=\"all\" />
";
        
        $__internal_f2aad5bcc79d21538a1867dae87a2604f230168397d88a0f6a9cee09b135a9fa->leave($__internal_f2aad5bcc79d21538a1867dae87a2604f230168397d88a0f6a9cee09b135a9fa_prof);

    }

    // line 7
    public function block_title($context, array $blocks = array())
    {
        $__internal_a301677a03741aee269847a9c50ac580790b07341cbb2d7cdbaab053701cf7af = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a301677a03741aee269847a9c50ac580790b07341cbb2d7cdbaab053701cf7af->enter($__internal_a301677a03741aee269847a9c50ac580790b07341cbb2d7cdbaab053701cf7af_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 8
        echo "    ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")), "message", array()), "html", null, true);
        echo " (";
        echo twig_escape_filter($this->env, (isset($context["status_code"]) ? $context["status_code"] : $this->getContext($context, "status_code")), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, (isset($context["status_text"]) ? $context["status_text"] : $this->getContext($context, "status_text")), "html", null, true);
        echo ")
";
        
        $__internal_a301677a03741aee269847a9c50ac580790b07341cbb2d7cdbaab053701cf7af->leave($__internal_a301677a03741aee269847a9c50ac580790b07341cbb2d7cdbaab053701cf7af_prof);

    }

    // line 11
    public function block_body($context, array $blocks = array())
    {
        $__internal_0ee4dd32f417615b8c6dc803fa30268ca1ce7cc7df0bdfac514e136d9d348ec7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0ee4dd32f417615b8c6dc803fa30268ca1ce7cc7df0bdfac514e136d9d348ec7->enter($__internal_0ee4dd32f417615b8c6dc803fa30268ca1ce7cc7df0bdfac514e136d9d348ec7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 12
        echo "    ";
        $this->loadTemplate("@Twig/Exception/exception.html.twig", "@Twig/Exception/exception_full.html.twig", 12)->display($context);
        
        $__internal_0ee4dd32f417615b8c6dc803fa30268ca1ce7cc7df0bdfac514e136d9d348ec7->leave($__internal_0ee4dd32f417615b8c6dc803fa30268ca1ce7cc7df0bdfac514e136d9d348ec7_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/exception_full.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  78 => 12,  72 => 11,  58 => 8,  52 => 7,  42 => 4,  36 => 3,  11 => 1,);
    }

    public function getSource()
    {
        return "{% extends '@Twig/layout.html.twig' %}

{% block head %}
    <link href=\"{{ absolute_url(asset('bundles/framework/css/exception.css')) }}\" rel=\"stylesheet\" type=\"text/css\" media=\"all\" />
{% endblock %}

{% block title %}
    {{ exception.message }} ({{ status_code }} {{ status_text }})
{% endblock %}

{% block body %}
    {% include '@Twig/Exception/exception.html.twig' %}
{% endblock %}
";
    }
}
