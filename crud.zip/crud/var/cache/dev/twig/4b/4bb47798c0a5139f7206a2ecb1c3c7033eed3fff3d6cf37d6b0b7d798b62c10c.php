<?php

/* crud/details.html.twig */
class __TwigTemplate_4d5b9715be677a7b1284cb29451aa837da00d5953767786f524080e7062d1520 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "crud/details.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_45a99544d2e72b64c38194e14d128a9cc5eb6c1231cad46b4df2c2b1eb09aaf9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_45a99544d2e72b64c38194e14d128a9cc5eb6c1231cad46b4df2c2b1eb09aaf9->enter($__internal_45a99544d2e72b64c38194e14d128a9cc5eb6c1231cad46b4df2c2b1eb09aaf9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "crud/details.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_45a99544d2e72b64c38194e14d128a9cc5eb6c1231cad46b4df2c2b1eb09aaf9->leave($__internal_45a99544d2e72b64c38194e14d128a9cc5eb6c1231cad46b4df2c2b1eb09aaf9_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_00b55d6b22d55c68b4ede8b05e4d8ea9940a7356a8c88d2562970eec7e39a022 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_00b55d6b22d55c68b4ede8b05e4d8ea9940a7356a8c88d2562970eec7e39a022->enter($__internal_00b55d6b22d55c68b4ede8b05e4d8ea9940a7356a8c88d2562970eec7e39a022_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "\t<h2 class=\"page-header\">";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["crud"]) ? $context["crud"] : $this->getContext($context, "crud")), "name", array()), "html", null, true);
        echo "</h2>
\t<ul class=\"list-group\">
\t<li class=\"list-group-item\">Mail: ";
        // line 6
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["crud"]) ? $context["crud"] : $this->getContext($context, "crud")), "mail", array()), "html", null, true);
        echo "</li>
\t<li class=\"list-group-item\">Mensaje: ";
        // line 7
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["crud"]) ? $context["crud"] : $this->getContext($context, "crud")), "message", array()), "html", null, true);
        echo "</li>
\t</ul>
\t<hr>
\t<a class=\"btn btn-default\" href=\"/\">Volver al Inicio</a>
";
        
        $__internal_00b55d6b22d55c68b4ede8b05e4d8ea9940a7356a8c88d2562970eec7e39a022->leave($__internal_00b55d6b22d55c68b4ede8b05e4d8ea9940a7356a8c88d2562970eec7e39a022_prof);

    }

    public function getTemplateName()
    {
        return "crud/details.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  50 => 7,  46 => 6,  40 => 4,  34 => 3,  11 => 1,);
    }

    public function getSource()
    {
        return "{% extends 'base.html.twig' %}

{% block body %}
\t<h2 class=\"page-header\">{{crud.name}}</h2>
\t<ul class=\"list-group\">
\t<li class=\"list-group-item\">Mail: {{crud.mail}}</li>
\t<li class=\"list-group-item\">Mensaje: {{crud.message}}</li>
\t</ul>
\t<hr>
\t<a class=\"btn btn-default\" href=\"/\">Volver al Inicio</a>
{% endblock %}";
    }
}
