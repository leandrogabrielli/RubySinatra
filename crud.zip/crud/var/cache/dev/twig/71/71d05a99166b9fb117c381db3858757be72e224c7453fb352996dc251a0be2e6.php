<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_e663ba7410eabdd9db67cc754376060c8e1681c1ce59d7a6428ea929424a9678 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_322e0412ec6fadf032068a2bed641cd5c0cb102930ed5ae11871d7626e26d1ee = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_322e0412ec6fadf032068a2bed641cd5c0cb102930ed5ae11871d7626e26d1ee->enter($__internal_322e0412ec6fadf032068a2bed641cd5c0cb102930ed5ae11871d7626e26d1ee_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_322e0412ec6fadf032068a2bed641cd5c0cb102930ed5ae11871d7626e26d1ee->leave($__internal_322e0412ec6fadf032068a2bed641cd5c0cb102930ed5ae11871d7626e26d1ee_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_7d261812b236877bafcbd1e1b35df2365318a071e68c94ad923bbdc88d611c97 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7d261812b236877bafcbd1e1b35df2365318a071e68c94ad923bbdc88d611c97->enter($__internal_7d261812b236877bafcbd1e1b35df2365318a071e68c94ad923bbdc88d611c97_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_7d261812b236877bafcbd1e1b35df2365318a071e68c94ad923bbdc88d611c97->leave($__internal_7d261812b236877bafcbd1e1b35df2365318a071e68c94ad923bbdc88d611c97_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_b5c90a07cca8783c542af2f93b1b6d340dca4849740a99e42ad9c5c40bdf1510 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b5c90a07cca8783c542af2f93b1b6d340dca4849740a99e42ad9c5c40bdf1510->enter($__internal_b5c90a07cca8783c542af2f93b1b6d340dca4849740a99e42ad9c5c40bdf1510_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_b5c90a07cca8783c542af2f93b1b6d340dca4849740a99e42ad9c5c40bdf1510->leave($__internal_b5c90a07cca8783c542af2f93b1b6d340dca4849740a99e42ad9c5c40bdf1510_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_8de23e9aa92bdeae203d297180e60c4eb314a32e5e822503a250b2a95ad49bd4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8de23e9aa92bdeae203d297180e60c4eb314a32e5e822503a250b2a95ad49bd4->enter($__internal_8de23e9aa92bdeae203d297180e60c4eb314a32e5e822503a250b2a95ad49bd4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\HttpKernelExtension')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_8de23e9aa92bdeae203d297180e60c4eb314a32e5e822503a250b2a95ad49bd4->leave($__internal_8de23e9aa92bdeae203d297180e60c4eb314a32e5e822503a250b2a95ad49bd4_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  73 => 13,  67 => 12,  56 => 7,  53 => 6,  47 => 5,  36 => 3,  11 => 1,);
    }

    public function getSource()
    {
        return "{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
";
    }
}
