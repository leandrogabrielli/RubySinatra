<?php

/* crud/edit.html.twig */
class __TwigTemplate_7fe68d10e51f3cee7e7528432eca9b898fe782b82b7d35cd3763037cca45cb86 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "crud/edit.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_fce420d6ee435e7679121edf15d65e508f439a2af55ba3c4717f667452f714e0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fce420d6ee435e7679121edf15d65e508f439a2af55ba3c4717f667452f714e0->enter($__internal_fce420d6ee435e7679121edf15d65e508f439a2af55ba3c4717f667452f714e0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "crud/edit.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_fce420d6ee435e7679121edf15d65e508f439a2af55ba3c4717f667452f714e0->leave($__internal_fce420d6ee435e7679121edf15d65e508f439a2af55ba3c4717f667452f714e0_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_9e04f5832121c138fd9e34f02daacb47489d22f4959b27874e9938affd6e2b50 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9e04f5832121c138fd9e34f02daacb47489d22f4959b27874e9938affd6e2b50->enter($__internal_9e04f5832121c138fd9e34f02daacb47489d22f4959b27874e9938affd6e2b50_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "\t<h2 class=\"page-header\">Editar Usuario</h2>
\t";
        // line 5
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start');
        echo "
\t";
        // line 6
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'widget');
        echo "
\t";
        // line 7
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
        echo "
";
        
        $__internal_9e04f5832121c138fd9e34f02daacb47489d22f4959b27874e9938affd6e2b50->leave($__internal_9e04f5832121c138fd9e34f02daacb47489d22f4959b27874e9938affd6e2b50_prof);

    }

    public function getTemplateName()
    {
        return "crud/edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  51 => 7,  47 => 6,  43 => 5,  40 => 4,  34 => 3,  11 => 1,);
    }

    public function getSource()
    {
        return "{% extends 'base.html.twig' %}

{% block body %}
\t<h2 class=\"page-header\">Editar Usuario</h2>
\t{{form_start(form)}}
\t{{form_widget(form)}}
\t{{form_end(form)}}
{% endblock %}";
    }
}
