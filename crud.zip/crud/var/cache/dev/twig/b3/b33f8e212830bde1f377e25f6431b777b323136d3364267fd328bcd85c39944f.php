<?php

/* crud/create.html.twig */
class __TwigTemplate_aaf67dc3814e0935e731a1f2ad47c418b425c53b890f7a25a5c818d34ee40d95 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "crud/create.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f085486e2ed240e2ec89846614d3518e1c06d13fac2f80299b78807616532bf7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f085486e2ed240e2ec89846614d3518e1c06d13fac2f80299b78807616532bf7->enter($__internal_f085486e2ed240e2ec89846614d3518e1c06d13fac2f80299b78807616532bf7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "crud/create.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_f085486e2ed240e2ec89846614d3518e1c06d13fac2f80299b78807616532bf7->leave($__internal_f085486e2ed240e2ec89846614d3518e1c06d13fac2f80299b78807616532bf7_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_c28e0f4c07a8ec3a28fe64b7c378558de1c638f68f66ed47d0dbec438c48c3e3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c28e0f4c07a8ec3a28fe64b7c378558de1c638f68f66ed47d0dbec438c48c3e3->enter($__internal_c28e0f4c07a8ec3a28fe64b7c378558de1c638f68f66ed47d0dbec438c48c3e3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "\t<h2 class=\"page-header\">Crear Usuario</h2>
\t";
        // line 5
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start');
        echo "
\t";
        // line 6
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'widget');
        echo "
\t";
        // line 7
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
        echo "
";
        
        $__internal_c28e0f4c07a8ec3a28fe64b7c378558de1c638f68f66ed47d0dbec438c48c3e3->leave($__internal_c28e0f4c07a8ec3a28fe64b7c378558de1c638f68f66ed47d0dbec438c48c3e3_prof);

    }

    public function getTemplateName()
    {
        return "crud/create.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  51 => 7,  47 => 6,  43 => 5,  40 => 4,  34 => 3,  11 => 1,);
    }

    public function getSource()
    {
        return "{% extends 'base.html.twig' %}

{% block body %}
\t<h2 class=\"page-header\">Crear Usuario</h2>
\t{{form_start(form)}}
\t{{form_widget(form)}}
\t{{form_end(form)}}
{% endblock %}";
    }
}
