<?php

/* base.html.twig */
class __TwigTemplate_b61809e295b1952fce2ae17fd0b20aff6e4e9a56b36a79661af3738e164f57da extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_44f9499c088149ae7327e618060b18bad7062868e2af3553db8b8ceed05ae8a3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_44f9499c088149ae7327e618060b18bad7062868e2af3553db8b8ceed05ae8a3->enter($__internal_44f9499c088149ae7327e618060b18bad7062868e2af3553db8b8ceed05ae8a3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html lang=\"en\">
  <head>
    <meta charset=\"utf-8\">
    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name=\"description\" content=\"\">
    <meta name=\"author\" content=\"\">
    <link rel=\"icon\" href=\"../../favicon.ico\">

    <title>";
        // line 12
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
    ";
        // line 13
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 14
        echo "
    <!-- Bootstrap core CSS -->
    <link href=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css\" rel=\"stylesheet\">
    <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        // line 17
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />

  </head>

  <body>

    <nav class=\"navbar navbar-inverse\">
      <div class=\"container\">
        <div class=\"navbar-header\">
          <button type=\"button\" class=\"navbar-toggle collapsed\" data-toggle=\"collapse\" data-target=\"#navbar\" aria-expanded=\"false\" aria-controls=\"navbar\">
            <span class=\"sr-only\">Toggle navigation</span>
            <span class=\"icon-bar\"></span>
            <span class=\"icon-bar\"></span>
            <span class=\"icon-bar\"></span>
          </button>
          <a class=\"navbar-brand\" href=\"#\">CRUD</a>
        </div>
        <div id=\"navbar\" class=\"collapse navbar-collapse\">
          <ul class=\"nav navbar-nav\">
            <li><a href=\"/\">Inicio</a></li>
            <li><a href=\"/crud/create\">Crear</a></li>
          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </nav>

    <div class=\"container\">
     
        <div class=\"row\">
            <div class=\"col-md-12\">
                ";
        // line 47
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "session", array()), "flashbag", array()), "get", array(0 => "notice"), "method"));
        foreach ($context['_seq'] as $context["_key"] => $context["flash_message"]) {
            // line 48
            echo "                  <div class=\"alert alert-info\">";
            echo twig_escape_filter($this->env, $context["flash_message"], "html", null, true);
            echo "</div>
                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['flash_message'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 50
        echo "
                ";
        // line 51
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "session", array()), "flashbag", array()), "get", array(0 => "error"), "method"));
        foreach ($context['_seq'] as $context["_key"] => $context["flash_message"]) {
            // line 52
            echo "                  <div class=\"alert alert-danger\">";
            echo twig_escape_filter($this->env, $context["flash_message"], "html", null, true);
            echo "</div>
                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['flash_message'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 54
        echo "                ";
        $this->displayBlock('body', $context, $blocks);
        // line 55
        echo "            </div>
        </div>

    </div>

";
        // line 60
        $this->displayBlock('javascripts', $context, $blocks);
        // line 61
        echo "
  </body>
</html>
";
        
        $__internal_44f9499c088149ae7327e618060b18bad7062868e2af3553db8b8ceed05ae8a3->leave($__internal_44f9499c088149ae7327e618060b18bad7062868e2af3553db8b8ceed05ae8a3_prof);

    }

    // line 12
    public function block_title($context, array $blocks = array())
    {
        $__internal_88bfec2b4f850f7cd0ad53ff4f71759cb4d03d14a06d790b63926ea978a325dc = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_88bfec2b4f850f7cd0ad53ff4f71759cb4d03d14a06d790b63926ea978a325dc->enter($__internal_88bfec2b4f850f7cd0ad53ff4f71759cb4d03d14a06d790b63926ea978a325dc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Welcome!";
        
        $__internal_88bfec2b4f850f7cd0ad53ff4f71759cb4d03d14a06d790b63926ea978a325dc->leave($__internal_88bfec2b4f850f7cd0ad53ff4f71759cb4d03d14a06d790b63926ea978a325dc_prof);

    }

    // line 13
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_7182fa5acf787edb56dc10123d1313f2a6fdd4b504c8d50ba294752a9937eb7c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7182fa5acf787edb56dc10123d1313f2a6fdd4b504c8d50ba294752a9937eb7c->enter($__internal_7182fa5acf787edb56dc10123d1313f2a6fdd4b504c8d50ba294752a9937eb7c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_7182fa5acf787edb56dc10123d1313f2a6fdd4b504c8d50ba294752a9937eb7c->leave($__internal_7182fa5acf787edb56dc10123d1313f2a6fdd4b504c8d50ba294752a9937eb7c_prof);

    }

    // line 54
    public function block_body($context, array $blocks = array())
    {
        $__internal_a6c5b39b2181175b2f4f15803814f692317bac31d8d869ac42dd834e15427466 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a6c5b39b2181175b2f4f15803814f692317bac31d8d869ac42dd834e15427466->enter($__internal_a6c5b39b2181175b2f4f15803814f692317bac31d8d869ac42dd834e15427466_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_a6c5b39b2181175b2f4f15803814f692317bac31d8d869ac42dd834e15427466->leave($__internal_a6c5b39b2181175b2f4f15803814f692317bac31d8d869ac42dd834e15427466_prof);

    }

    // line 60
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_11ccefbef25e69c87897c75ccb968cf7dda5826f00738549a9a8655dc4dc8933 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_11ccefbef25e69c87897c75ccb968cf7dda5826f00738549a9a8655dc4dc8933->enter($__internal_11ccefbef25e69c87897c75ccb968cf7dda5826f00738549a9a8655dc4dc8933_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        
        $__internal_11ccefbef25e69c87897c75ccb968cf7dda5826f00738549a9a8655dc4dc8933->leave($__internal_11ccefbef25e69c87897c75ccb968cf7dda5826f00738549a9a8655dc4dc8933_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  168 => 60,  157 => 54,  146 => 13,  134 => 12,  124 => 61,  122 => 60,  115 => 55,  112 => 54,  103 => 52,  99 => 51,  96 => 50,  87 => 48,  83 => 47,  50 => 17,  45 => 14,  43 => 13,  39 => 12,  26 => 1,);
    }

    public function getSource()
    {
        return "<!DOCTYPE html>
<html lang=\"en\">
  <head>
    <meta charset=\"utf-8\">
    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name=\"description\" content=\"\">
    <meta name=\"author\" content=\"\">
    <link rel=\"icon\" href=\"../../favicon.ico\">

    <title>{% block title %}Welcome!{% endblock %}</title>
    {% block stylesheets %}{% endblock %}

    <!-- Bootstrap core CSS -->
    <link href=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css\" rel=\"stylesheet\">
    <link rel=\"icon\" type=\"image/x-icon\" href=\"{{ asset('favicon.ico') }}\" />

  </head>

  <body>

    <nav class=\"navbar navbar-inverse\">
      <div class=\"container\">
        <div class=\"navbar-header\">
          <button type=\"button\" class=\"navbar-toggle collapsed\" data-toggle=\"collapse\" data-target=\"#navbar\" aria-expanded=\"false\" aria-controls=\"navbar\">
            <span class=\"sr-only\">Toggle navigation</span>
            <span class=\"icon-bar\"></span>
            <span class=\"icon-bar\"></span>
            <span class=\"icon-bar\"></span>
          </button>
          <a class=\"navbar-brand\" href=\"#\">CRUD</a>
        </div>
        <div id=\"navbar\" class=\"collapse navbar-collapse\">
          <ul class=\"nav navbar-nav\">
            <li><a href=\"/\">Inicio</a></li>
            <li><a href=\"/crud/create\">Crear</a></li>
          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </nav>

    <div class=\"container\">
     
        <div class=\"row\">
            <div class=\"col-md-12\">
                {% for flash_message in app.session.flashbag.get('notice') %}
                  <div class=\"alert alert-info\">{{flash_message}}</div>
                {% endfor %}

                {% for flash_message in app.session.flashbag.get('error') %}
                  <div class=\"alert alert-danger\">{{flash_message}}</div>
                {% endfor %}
                {% block body %}{% endblock %}
            </div>
        </div>

    </div>

{% block javascripts %}{% endblock %}

  </body>
</html>
";
    }
}
