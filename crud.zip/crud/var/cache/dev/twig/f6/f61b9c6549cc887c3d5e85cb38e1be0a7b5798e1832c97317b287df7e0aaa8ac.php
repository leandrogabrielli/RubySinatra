<?php

/* crud/index.html.twig */
class __TwigTemplate_7e5cc711183f47e566b62589ec50d938b236a5683f2c7765e9c941d97b1308f8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "crud/index.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_84903682d1754baf7e0252356721b03786f23173c84082539d41ad59c8ac6ac1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_84903682d1754baf7e0252356721b03786f23173c84082539d41ad59c8ac6ac1->enter($__internal_84903682d1754baf7e0252356721b03786f23173c84082539d41ad59c8ac6ac1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "crud/index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_84903682d1754baf7e0252356721b03786f23173c84082539d41ad59c8ac6ac1->leave($__internal_84903682d1754baf7e0252356721b03786f23173c84082539d41ad59c8ac6ac1_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_1decf488fdfc086890f87d80fdad2a50929e28fbc341b5754084c8ce49df6d41 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1decf488fdfc086890f87d80fdad2a50929e28fbc341b5754084c8ce49df6d41->enter($__internal_1decf488fdfc086890f87d80fdad2a50929e28fbc341b5754084c8ce49df6d41_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "\t<h2 class=\"page-header\">Usuarios</h2>
\t<table class=\"table table-stripped\">
\t<thead>
\t<tr>
\t<th>#</th>
\t<th>Nombre</th>
\t<th>Mail</th>
\t<th>Mensaje</th>
\t<th></th>
\t</tr>
\t</thead>
\t<tbody>
\t";
        // line 16
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["cruds"]) ? $context["cruds"] : $this->getContext($context, "cruds")));
        foreach ($context['_seq'] as $context["_key"] => $context["crud"]) {
            // line 17
            echo "
\t<tr>
\t<th scope=\"row\">";
            // line 19
            echo twig_escape_filter($this->env, $this->getAttribute($context["crud"], "id", array()), "html", null, true);
            echo "</th>
\t<td>";
            // line 20
            echo twig_escape_filter($this->env, $this->getAttribute($context["crud"], "name", array()), "html", null, true);
            echo "</td>
\t<td>";
            // line 21
            echo twig_escape_filter($this->env, $this->getAttribute($context["crud"], "mail", array()), "html", null, true);
            echo "</td>
\t<td>";
            // line 22
            echo twig_escape_filter($this->env, $this->getAttribute($context["crud"], "message", array()), "html", null, true);
            echo "</td>
\t<td>
\t<a href=\"/crud/details/";
            // line 24
            echo twig_escape_filter($this->env, $this->getAttribute($context["crud"], "id", array()), "html", null, true);
            echo "\" class=\"btn btn-success\">Ver</a>
\t<a href=\"/crud/edit/";
            // line 25
            echo twig_escape_filter($this->env, $this->getAttribute($context["crud"], "id", array()), "html", null, true);
            echo "\" class=\"btn btn-warning\">Editar</a>
\t<a href=\"/crud/delete/";
            // line 26
            echo twig_escape_filter($this->env, $this->getAttribute($context["crud"], "id", array()), "html", null, true);
            echo "\" class=\"btn btn-danger\">Eliminar</a>
\t</td>
\t</tr>
\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['crud'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 30
        echo "\t</tbody> 
";
        
        $__internal_1decf488fdfc086890f87d80fdad2a50929e28fbc341b5754084c8ce49df6d41->leave($__internal_1decf488fdfc086890f87d80fdad2a50929e28fbc341b5754084c8ce49df6d41_prof);

    }

    public function getTemplateName()
    {
        return "crud/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  97 => 30,  87 => 26,  83 => 25,  79 => 24,  74 => 22,  70 => 21,  66 => 20,  62 => 19,  58 => 17,  54 => 16,  40 => 4,  34 => 3,  11 => 1,);
    }

    public function getSource()
    {
        return "{% extends 'base.html.twig' %}

{% block body %}
\t<h2 class=\"page-header\">Usuarios</h2>
\t<table class=\"table table-stripped\">
\t<thead>
\t<tr>
\t<th>#</th>
\t<th>Nombre</th>
\t<th>Mail</th>
\t<th>Mensaje</th>
\t<th></th>
\t</tr>
\t</thead>
\t<tbody>
\t{% for crud in cruds %}

\t<tr>
\t<th scope=\"row\">{{crud.id}}</th>
\t<td>{{crud.name}}</td>
\t<td>{{crud.mail}}</td>
\t<td>{{crud.message}}</td>
\t<td>
\t<a href=\"/crud/details/{{crud.id}}\" class=\"btn btn-success\">Ver</a>
\t<a href=\"/crud/edit/{{crud.id}}\" class=\"btn btn-warning\">Editar</a>
\t<a href=\"/crud/delete/{{crud.id}}\" class=\"btn btn-danger\">Eliminar</a>
\t</td>
\t</tr>
\t{% endfor %}
\t</tbody> 
{% endblock %}";
    }
}
